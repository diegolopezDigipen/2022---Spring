/* ---------------------------------------------------------------------------------------------------------
Copyright (C) 2022 DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents without the prior written
consent of DigiPen Institute of Technology is prohibited.
Project: cs250_diego.lopez_1
Author: Diego Lopez, diego.lopez, 540001220
Creation date: 14/01/2022
Details: This project has the basic operations for a Math Library to work with Points and Vectors of 4 and 4x4 Matrixes
----------------------------------------------------------------------------------------------------------*/